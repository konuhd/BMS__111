from PyQt5.QtCore import QPoint
from PyQt5.QtWidgets import QTabBar, QStyleOptionTab, QStylePainter, QStyle
from PySide6.QtGui import QPainter, QIcon
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QGraphicsOpacityEffect, QDialog, QHBoxLayout, \
    QLineEdit, QPushButton, QTabWidget
from PySide6.QtCore import QPropertyAnimation, Qt, Slot, QRect

from pythonProject.sql import Sql
from functools import wraps

class FadeOutLabel(QLabel):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.initFadeOutAnimation()

    def initFadeOutAnimation(self):
        # 创建透明度效果
        self.opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.opacity_effect)

        # 创建动画对象
        self.animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.animation.setDuration(3000)  # 动画持续时间，单位为毫秒
        self.animation.setStartValue(1.0)  # 开始时的不透明度
        self.animation.setEndValue(0.0)  # 结束时的不透明度

        # 动画结束后隐藏标签
        self.animation.finished.connect(self.clear)

    @Slot()
    def on_animation_finished(self):
        self.hide()

    def startFadeOut(self):
        self.animation.start()


class EditDialog(QDialog):
    def __init__(self,bookid="", bookname="", publicationDate="", publisher="", bookrackid="", roomid=""):
        super().__init__()
        self.setWindowTitle("modify data")
        self.bookid=bookid
        self.bookname=bookname
        self.publicationDate=publicationDate
        self.publisher=publisher
        self.bookrackid=bookrackid
        self.roomid=roomid
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()


        bookname_layout = QHBoxLayout()
        bookname_label = QLabel('bookname:')
        self.bookname_edit = QLineEdit(self.bookname)
        bookname_layout.addWidget(bookname_label)
        bookname_layout.addWidget(self.bookname_edit)
        layout.addLayout(bookname_layout)

        # 添加 publicationDate 行
        publicationDate_layout = QHBoxLayout()
        publicationDate_label = QLabel('publicationDate:')
        self.publicationDate_edit = QLineEdit(self.publicationDate)
        publicationDate_layout.addWidget(publicationDate_label)
        publicationDate_layout.addWidget(self.publicationDate_edit)
        layout.addLayout(publicationDate_layout)

        # 添加 publisher 行
        publisher_layout = QHBoxLayout()
        publisher_label = QLabel('publisher:')
        self.publisher_edit = QLineEdit(self.publisher)
        publisher_layout.addWidget(publisher_label)
        publisher_layout.addWidget(self.publisher_edit)
        layout.addLayout(publisher_layout)

        # 添加 bookrackid 行
        bookrackid_layout = QHBoxLayout()
        bookrackid_label = QLabel('bookrackid:')
        self.bookrackid_edit = QLineEdit(self.bookrackid)
        bookrackid_layout.addWidget(bookrackid_label)
        bookrackid_layout.addWidget(self.bookrackid_edit)
        layout.addLayout(bookrackid_layout)

        # 添加 roomid 行
        roomid_layout = QHBoxLayout()
        roomid_label = QLabel('roomid:')
        self.roomid_edit = QLineEdit(self.roomid)
        roomid_layout.addWidget(roomid_label)
        roomid_layout.addWidget(self.roomid_edit)
        layout.addLayout(roomid_layout)


        button_layout = QHBoxLayout()
        ok_button = QPushButton('OK')
        cancel_button = QPushButton('Cancel')
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)

        ok_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)

        self.setLayout(layout)

    def get_values(self):
        return (self.bookname_edit.text(),
                self.publicationDate_edit.text(),self.publisher_edit.text(),
                self.bookrackid_edit.text(),self.roomid_edit.text())

    def accept(self):
        Sql().modify(self.bookid,self.bookname_edit.text(),
                self.publicationDate_edit.text(),self.publisher_edit.text(),
                self.bookrackid_edit.text(),self.roomid_edit.text())
        super().accept()

