import pymysql
class Sql:
    def __init__(self):
        self.connect=pymysql.connect(host="localhost",user="root",password="root",database="BMS",port=3306)

    def show(self):
        with self.connect.cursor() as cursor:
            sql="select * from books;"
            cursor.execute(sql)
            res=cursor.fetchall()
            return res

    def search_user(self,key=None):
        with self.connect.cursor() as cursor:
            if key==None:
                sql="select * from usr;"
                cursor.execute(sql)
            else:
                sql="select * from usr where id=%s or usrname=%s"
                cursor.execute(sql,(key,key))
            res = cursor.fetchall()
            return res


    def insert(self,bookid, bookname, publicationDate, pulisher, bookrackid, roomid):
        with self.connect.cursor() as cursor:
            sql = "INSERT INTO books (bookid, bookname, publicationDate, publisher, bookrackid, roomid) VALUES (%s,%s,%s,%s,%s, %s);"
            cursor.execute(sql, (bookid, bookname, publicationDate, pulisher, bookrackid, roomid))

    def delete(self, bookid, bookname, publicationDate, publisher, bookrackid, roomid):
        with self.connect.cursor() as cursor:
            # 构建删除语句
            sql = """
              DELETE FROM books
              WHERE bookid = %s AND bookname = %s AND publicationDate = %s 
              AND publisher = %s AND bookrackid = %s AND roomid = %s
              """
            cursor.execute(sql, (bookid, bookname, publicationDate, publisher, bookrackid, roomid))
            self.connect.commit()


    def modify(self, bookid, bookname, publicationDate, publisher, bookrackid, roomid):
        with self.connect.cursor() as cursor:
            sql = "UPDATE books SET bookname=%s, publicationDate=%s, publisher=%s, bookrackid=%s, roomid=%s WHERE bookid=%s"
            cursor.execute(sql, (bookname, publicationDate, publisher, bookrackid, roomid, bookid))
        self.connect.commit()
        self.connect.close()



    def search(self,search=""):
        with self.connect.cursor() as cursor:
            sql = "select * from books where bookname=%s or publisher= %s;"
            cursor.execute(sql, (search,search))
            return cursor.fetchall()


    def change_pwd(self,account,new_pwd):
        with self.connect.cursor() as cursor:
            sql="update usr set passwd=%s where usrname=%s;"
            cursor.execute(sql,(new_pwd,account))

    def GetUserId(self,username):
        with self.connect.cursor() as cursor:
            sql="select id from usr where usrname= %s"
            cursor.execute(sql,(username,))
            return cursor.fetchone()[0]

    def GetUserIsRoot(self,username=""):
        id=self.GetUserId(username)
        with self.connect.cursor() as cursor:
            sql="select is_root from usr where id= %s"
            cursor.execute(sql,(id,))
            return cursor.fetchone()[0]




def get_pa_db(usr):
    connect = pymysql.connect(host="localhost", user="root", password="root", database="BMS", port=3306)
    with connect.cursor() as cursor:
        sql="select passwd,is_root from usr where usrname=%s"
        cursor.execute(sql,(usr,))
        return cursor.fetchone()[0]

