import sys
from modulefinder import Module

import pymysql
from PyQt5.QtCore import QPoint
from PyQt5.QtWidgets import QTabBar, QStyleOptionTab, QStylePainter, QStyle
from PySide6.QtGui import QPainter, QIcon
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QGraphicsOpacityEffect, QDialog, QHBoxLayout, \
    QLineEdit, QPushButton, QTabWidget, QMessageBox
from PySide6.QtCore import QPropertyAnimation, Qt, Slot, QRect
from sqlclient import Sql
class EditDialog(QDialog):
    def __init__(self,bookid,bookname,usr):
        super().__init__()
        self.setWindowTitle("borrow")
        self.bookid=bookid
        self.bookname=bookname
        self.StartDate=""
        self.EndDate=""
        self.usrid=Sql().GetUserId(usr)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        bookid_layout = QHBoxLayout()
        bookid_label = QLabel('bookid:')
        self.bookid_edit = QLineEdit(self.bookid)
        self.bookid_edit.setReadOnly(True)
        bookid_layout.addWidget(bookid_label)
        bookid_layout.addWidget(self.bookid_edit)
        layout.addLayout(bookid_layout)

        bookname_layout = QHBoxLayout()
        bookname_label = QLabel('bookname:')
        self.bookname_edit = QLineEdit(self.bookname)
        self.bookname_edit.setReadOnly(True)
        bookname_layout.addWidget(bookname_label)
        bookname_layout.addWidget(self.bookname_edit)
        layout.addLayout(bookname_layout)

        # 添加 StartDate 行
        StartDate_layout = QHBoxLayout()
        StartDate_label = QLabel('StartDate:')
        self.StartDate_edit = QLineEdit(self.StartDate)
        StartDate_layout.addWidget(StartDate_label)
        StartDate_layout.addWidget(self.StartDate_edit)
        layout.addLayout(StartDate_layout)

        # 添加 EndDate 行
        EndDate_layout = QHBoxLayout()
        EndDate_label = QLabel('EndDate:')
        self.EndDate_edit = QLineEdit(self.EndDate)
        EndDate_layout.addWidget(EndDate_label)
        EndDate_layout.addWidget(self.EndDate_edit)
        layout.addLayout(EndDate_layout)


        button_layout = QHBoxLayout()
        ok_button = QPushButton('OK')
        cancel_button = QPushButton('Cancel')
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
        #
        ok_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        self.setLayout(layout)

    def accept(self):
        try:
            Sql().add_borrow(self.usrid,self.bookid_edit.text(),self.StartDate_edit.text(),self.EndDate_edit.text())
            super().accept()
        except pymysql.err.OperationalError:
            self.show_message("借阅日期和截止日期不能为空")
        except pymysql.err.IntegrityError:
            self.show_message("该书已在库中")


    def getvalues(self):
        return self.StartDate_edit.text(),self.EndDate_edit.text()

    def show_message(self,s):
        msg_box = QMessageBox()
        msg_box.setWindowTitle("提示")
        msg_box.setText(s)
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.exec()



