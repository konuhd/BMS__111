import os,sys
current_path=os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_path)


from PySide6.QtWidgets import QMainWindow, QTableView
from client import *
from datetime import *

from sqlclient import *
from diy_Dialog import *
class Client(Ui_Form, QMainWindow):
    def __init__(self,user):
        super().__init__()
        self.setupUi(self)
        self.table1Widget.setColumnCount(7)
        self.table1Widget.setHorizontalHeaderLabels(
            ["bookid", "bookname", "publicationDate", "publisher", "bookrackid", "roomid", "borrow"])
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(["bookid", "bookname", "BorrowDate", "ReturnDate","return"])
        self.tableWidget.horizontalHeader().setVisible(False)
        self.tableWidget.show()
        # self.table1Widget.show()
        self.refresh_search()
        self.user=user
        self.id=Sql().GetUserId(username=self.user)
        self.table1Widget.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        self.showborrow()
    def refresh_search(self):
        key=self.search_line.text()
        data=None
        self.table1Widget.setRowCount(0)
        self.table1Widget.setColumnCount(7)
        self.table1Widget.setHorizontalHeaderLabels(
            ["bookid", "bookname", "publicationDate", "publisher", "bookrackid","roomid" ,"borrow"])
        if key=="":
            data=Sql().show()
        else:
            data=Sql().search(key)
        for it in range(len(data)):
            self.table1Widget.insertRow(it)
            (bookid, bookname, publicationDate, publisher, bookrackid, roomid) =data[it]
            publication_date_str = publicationDate.strftime("%Y-%m-%d") if isinstance(publicationDate, datetime) else ""
            self.table1Widget.setItem(it, 0, QTableWidgetItem(str(bookid)))
            self.table1Widget.setItem(it, 1, QTableWidgetItem(bookname))
            self.table1Widget.setItem(it, 2, QTableWidgetItem(publication_date_str))
            self.table1Widget.setItem(it, 3, QTableWidgetItem(publisher))
            self.table1Widget.setItem(it, 4, QTableWidgetItem(str(bookrackid)))
            self.table1Widget.setItem(it, 5, QTableWidgetItem(str(roomid)))

            button_borrow = QPushButton('借阅')
            button_borrow.clicked.connect(lambda checked, r=it: self.borrow_book(r))
            self.table1Widget.setCellWidget(it, 6, button_borrow)
            self.table1Widget.verticalHeader().setVisible(False)
    def borrow_book(self,row:int):
        bookid, bookname, publicationDate, publisher, bookrackid, roomid = self.table1Widget.item(row,
                                                                                                  0).text(), self.table1Widget.item(
            row, 1).text(), self.table1Widget.item(row, 2).text(), self.table1Widget.item(row,
                                                                                          3).text(), self.table1Widget.item(
            row, 4).text(), self.table1Widget.item(row, 5).text()
        costom=EditDialog(bookid, bookname,self.user)
        if costom.exec():
            StartDate,EndDate=costom.getvalues()
            print(bookid, bookname, StartDate, EndDate)
            row_c=self.tableWidget.rowCount()
            self.tableWidget.insertRow(row_c)
            self.tableWidget.setItem(row_c,0,QTableWidgetItem(str(bookid)))
            self.tableWidget.setItem(row_c,1,QTableWidgetItem(bookname))
            self.tableWidget.setItem(row_c,2,QTableWidgetItem(StartDate))
            self.tableWidget.setItem(row_c,3,QTableWidgetItem(EndDate))
            button_borrow = QPushButton('归还')
            button_borrow.clicked.connect(lambda checked, r=row_c: self.return_book(r))
            self.tableWidget.setCellWidget(row_c, 4, button_borrow)
        if self.tableWidget.rowCount()!=0:
            self.label_2.setVisible(False)
            self.tableWidget.horizontalHeader().setVisible(True)
            self.tableWidget.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            self.tableWidget.verticalHeader().setVisible(False)
    def showborrow(self):
        data=Sql().borrow_show(self.id)
        for i in data:
            if i is not None:
                row_c = self.tableWidget.rowCount()
                self.tableWidget.insertRow(row_c)
                for j in range(4):
                    self.tableWidget.setItem(row_c, j, QTableWidgetItem(str(i[j])))
                button_borrow = QPushButton('归还')
                button_borrow.clicked.connect(lambda checked, r=row_c: self.return_book(r))
                self.tableWidget.setCellWidget(row_c, 4, button_borrow)
            else:
                self.tableWidget.setRowCount(0)
        if self.tableWidget.rowCount()!=0:
            self.label_2.setVisible(False)
            self.tableWidget.horizontalHeader().setVisible(True)
            self.tableWidget.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            self.tableWidget.verticalHeader().setVisible(False)
    def return_book(self,r):
        Sql().remove(self.id,self.tableWidget.item(r,0).text())
        self.tableWidget.setRowCount(0)
        self.label_2.setVisible(True)
        self.tableWidget.horizontalHeader().setVisible(False)
        self.tableWidget.verticalHeader().setVisible(True)
        self.showborrow()
if __name__ == "__main__":
    app = QApplication([])
    dialog = Client("test")
    dialog.show()
    sys.exit(app.exec())
