# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'client.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QTabWidget, QTableWidget,
    QTableWidgetItem, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(847, 536)
        Form.setStyleSheet(u"#label{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#tabWidget{\n"
"board:none;\n"
"}\n"
"#add{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#add:hover{\n"
"	background-color: rgb(255, 255, 255);\n"
"}\n"
"#sub{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#sub:hover{\n"
"	background-color: rgb(255, 255, 255);\n"
"}")
        self.tabWidget = QTabWidget(Form)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(0, 0, 841, 531))
        self.tabWidget.setStyleSheet(u"#search_line{\n"
"	background:transparent;\n"
"	border:none;\n"
"	border-bottom:1px solid  rgb(0, 0, 0);\n"
"}\n"
"QTabBar::tab{\n"
"	height: 40px;\n"
"	width :150px;\n"
"	outline:none;\n"
"	background-color: rgb(0, 170, 255);\n"
"	font: 700 9pt \"Segoe Print\";\n"
"}\n"
"\n"
"QTabBar::tab:!selected{\n"
"	outline:none;\n"
"	background-color: rgb(175, 175, 175);\n"
"}\n"
"QTabBar::tab:selected:focus{\n"
"	border:none;\n"
"	outline:none;\n"
"}\n"
"QTabBar::tab:hover{\n"
"	outline:none;\n"
"	background-color: rgb(255, 255, 255);\n"
"}\n"
"#submit{\n"
"	border-radius:10px;\n"
"	background-color: rgb(223, 223, 223);\n"
"	outline:none;\n"
"}\n"
"#submit:hover{\n"
"	background-color: rgb(21, 21, 21);\n"
"}")
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.North)
        self.tabWidget.setTabShape(QTabWidget.TabShape.Triangular)
        self.tabWidget.setElideMode(Qt.TextElideMode.ElideRight)
        self.tabWidget.setTabsClosable(False)
        self.tabWidget.setTabBarAutoHide(False)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.search_line = QLineEdit(self.tab)
        self.search_line.setObjectName(u"search_line")
        self.search_line.setGeometry(QRect(250, 20, 251, 20))
        self.search_button = QPushButton(self.tab)
        self.search_button.setObjectName(u"search_button")
        self.search_button.setGeometry(QRect(510, 20, 24, 22))
        icon = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.EditFind))
        self.search_button.setIcon(icon)
        self.table1Widget = QTableWidget(self.tab)
        self.table1Widget.setObjectName(u"table1Widget")
        self.table1Widget.setGeometry(QRect(0, 40, 841, 441))
        self.label = QLabel(self.tab)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 0, 841, 41))
        self.tabWidget.addTab(self.tab, icon, "")
        self.label.raise_()
        self.search_line.raise_()
        self.search_button.raise_()
        self.table1Widget.raise_()
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.tableWidget = QTableWidget(self.tab_2)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(0, 10, 811, 461))
        self.label_2 = QLabel(self.tab_2)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(240, 190, 281, 51))
        self.label_2.setStyleSheet(u"font: 26pt \"Microsoft YaHei UI\";\n"
"color: rgb(255, 0, 0);\n"
"")
        self.tabWidget.addTab(self.tab_2, "")

        self.retranslateUi(Form)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
#if QT_CONFIG(whatsthis)
        self.search_line.setWhatsThis(QCoreApplication.translate("Form", u"<html><head/><body><p><br/></p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.search_button.setText("")
        self.label.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("Form", u"\u67e5\u627e/\u501f\u9605\u56fe\u4e66", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"\u6682\u65f6\u6ca1\u6709\u501f\u9605\u8bb0\u5f55", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("Form", u"\u6211\u7684\u501f\u9605", None))
    # retranslateUi

