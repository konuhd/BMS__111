import pymysql
class Sql:
    def __init__(self):
        self.connect=pymysql.connect(host="localhost",user="root",password="root",database="BMS",port=3306)

    def show(self):
        with self.connect.cursor() as cursor:
            sql="select * from books;"
            cursor.execute(sql)
            res=cursor.fetchall()
            return res

    def search_user(self,key=None):
        with self.connect.cursor() as cursor:
            if key==None:
                sql="select * from usr;"
            else:
                sql="select * from usr where id=%s and usrname=%s" .format(key,key)
            cursor.execute(sql)
            res = cursor.fetchall()
            return res

    def search(self,search=""):
        with self.connect.cursor() as cursor:
            sql = "select * from books where bookname=%s or publisher= %s;"
            cursor.execute(sql, (search,search))
            return cursor.fetchall()


    def change_pwd(self,account,new_pwd):
        with self.connect.cursor() as cursor:
            sql="update usr set passwd=%s where usrname=%s;"
            cursor.execute(sql,(new_pwd,account))

    def add_borrow(self,*args)->None:
        with self.connect.cursor() as cursor:
            sql="insert into borrow(borrowBookid, bookid, borrowDate, returnDate) VALUE(%s,%s,%s,%s);"
            cursor.execute(sql,(*args,))
    def GetUserId(self,username):
        with self.connect.cursor() as cursor:
            sql="select id from usr where usrname= %s"
            cursor.execute(sql,(username,))
            return cursor.fetchone()[0]

    def GetUserIsRoot(self,username=""):
        id=self.GetUserId(username)
        with self.connect.cursor() as cursor:
            sql="select is_root from usr where id= %s"
            cursor.execute(sql,(id,))
            return cursor.fetchone()[0]
    def borrow_show(self,id):
        with self.connect.cursor() as cursor:
            sql="select b.bookid,bookname,borrowDate,returnDate from borrow left outer join bms.books b on borrow.bookid = b.bookid left outer join bms.usr b2 on borrow.borrowBookid = b2.id where id=%s"
            cursor.execute(sql,(id,))
            return cursor.fetchall()
    def remove(self,borrowid,bookid):
        with self.connect.cursor() as cursor:
            sql="delete from borrow where borrowBookid=%s and bookid=%s"
            cursor.execute(sql,(borrowid,bookid))
def get_pa_db(usr):
    connect = pymysql.connect(host="localhost", user="root", password="root", database="BMS", port=3306)
    with connect.cursor() as cursor:
        sql="select passwd,is_root from usr where usrname=%s"
        cursor.execute(sql,(usr,))
        return cursor.fetchone()[0]

