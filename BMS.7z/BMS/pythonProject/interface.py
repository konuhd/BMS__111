import time
from datetime import datetime

from PyQt5.QtWidgets import QTableWidget
from PySide6.QtCore import (Qt)
from PySide6.QtGui import (QColor, QStandardItemModel, QStandardItem,
                           QPalette)
from PySide6.QtWidgets import (QLineEdit, QMainWindow, QDialog,
                               QTableView, QTableWidgetItem, QWidget, QHBoxLayout, QPushButton, QAbstractItemView,
                               QTabWidget)
import change_pwd
from login_ui import Ui_Dialog
from pythonProject import qfading
from pythonProject.client.client_use import Client
from sql import Sql
from sql import get_pa_db
from qfading import EditDialog
class CustomDialog(QDialog,Ui_Dialog):
    def __init__(self):
        super(CustomDialog, self).__init__()
        self.setupUi(self)
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.pushButton.clicked.connect(self.get_mes_from_ui)
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.pushButton_2.clicked.connect(self.close)
        self.pushButton_3.clicked.connect(self.showMinimized)
    def get_mes_from_ui(self):
        self.get_usr = self.usrname.text()
        self.get_password = self.password.text()
        # print(Sql().GetUserIsRoot(username=self.get_usr),self.get_usr )
        if self.get_password=="" or self.get_usr=="":
            self.label_4.setText("用户名或密码不能为空")
            self.label_4.startFadeOut()
            return
        try:
            if self.get_password==get_pa_db(self.get_usr):
                self.close()
                if Sql().GetUserIsRoot(username=self.get_usr)==1:
                    self.main_window = MainShow(self.get_usr)
                else:
                    self.main_window=Client(self.get_usr)  # 创建主窗口实例
                self.main_window.show()
            else:
                self.label_4.setText("密码错误")
                self.label_4.startFadeOut()
        except TypeError:
            self.label_4.setText("账号不存在")
            self.label_4.startFadeOut()

    # -----------------------------------------------------------------
    def mousePressEvent(self, event):
        if event.button()==Qt.MouseButton.LeftButton:
            self._old_pos=event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self._old_pos is not None:
            delta=event.globalPosition().toPoint()-self._old_pos
            self.move(self.x()+delta.x(),self.y()+delta.y())
            self._old_pos=event.globalPosition().toPoint()
# ---------------------------------------------------------------


from mainwindows import Ui_Form
class MainShow(Ui_Form, QMainWindow):
    def __init__(self,usrname):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle("管理员端")
        self.add.clicked.connect(self.add_line)
        self.sub.clicked.connect(self.sub_line)
        self.submit.clicked.connect(self.submit_msg)
        self.table1Widget.setColumnCount(7)
        self.table1Widget.setHorizontalHeaderLabels(
            ["bookid", "bookname", "publicationDate", "publisher", "bookrackid", "roomid","modify","remove"])
        self.table1Widget.show()
        self.refresh_search()
        self.table1Widget.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        self.usrname=usrname
        # self.usrname_show.setText(usrname)
        self.search_button.clicked.connect(self.refresh_search)
        self.change_password.clicked.connect(self.change_pwd_funct)
        # self.exit_button.clicked.connect(self.exit_)
        self.show_usr.setColumnCount(5)
        self.show_usr.setHorizontalHeaderLabels(["username", "password","is_root","modify","remove"])
        self.show_usr.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
        self.usrshow()
        self.pushbutton.clicked.connect(self.usrshow)



    def add_line(self):
        self.tableWidget.insertRow(self.tableWidget.rowCount())

    def sub_line(self):
        self.tableWidget.removeRow(self.tableWidget.rowCount()-1)

    def submit_msg(self):
        for index in range(self.tableWidget.rowCount()):
            bookid=self.tableWidget.item(index,0)
            bookname=self.tableWidget.item(index,1)
            publicationDate=self.tableWidget.item(index,2)
            publisher=self.tableWidget.item(index,3)
            bookrackid=self.tableWidget.item(index,4)
            roomid=self.tableWidget.item(index,5)
            Sql().insert(bookid.text(), bookname.text(), publicationDate.text(), publisher.text(), bookrackid.text(), roomid.text())
        self.tableWidget.setRowCount(0)
        self.submit_label.setText("添加成功")
        self.submit_label.startFadeOut()


    def refresh_search(self):
        key=self.search_line.text()
        data=None
        self.table1Widget.setRowCount(0)
        self.table1Widget.setColumnCount(8)
        self.table1Widget.setHorizontalHeaderLabels(
            ["bookid", "bookname", "publicationDate", "publisher", "bookrackid", "roomid","modify","remove"])
        if key=="":
            data=Sql().show()
        else:
            data=Sql().search(key)
        for it in range(len(data)):
            self.table1Widget.insertRow(it)
            (bookid, bookname, publicationDate, publisher, bookrackid, roomid) =data[it]
            publication_date_str = publicationDate.strftime("%Y-%m-%d") if isinstance(publicationDate, datetime) else ""
            self.table1Widget.setItem(it, 0, QTableWidgetItem(str(bookid)))
            self.table1Widget.setItem(it, 1, QTableWidgetItem(bookname))
            self.table1Widget.setItem(it, 2, QTableWidgetItem(publication_date_str))
            self.table1Widget.setItem(it, 3, QTableWidgetItem(publisher))
            self.table1Widget.setItem(it, 4, QTableWidgetItem(str(bookrackid)))
            self.table1Widget.setItem(it, 5, QTableWidgetItem(str(roomid)))
            button = QPushButton('修改')
            button.clicked.connect(lambda checked, r=it: self.edit_row(r))
            self.table1Widget.setCellWidget(it, 6, button)

            button_delete = QPushButton('删除')
            button_delete.clicked.connect(lambda checked, r=it: self.drop(r))
            self.table1Widget.setCellWidget(it, 7, button_delete)
            self.table1Widget.verticalHeader().setVisible(False)

    def drop(self,row):
        bookid, bookname, publicationDate, publisher, bookrackid, roomid=self.table1Widget.item(row,0).text(),self.table1Widget.item(row,1).text(),self.table1Widget.item(row,2).text(),self.table1Widget.item(row,3).text(),self.table1Widget.item(row,4).text(),self.table1Widget.item(row,5).text()
        Sql().delete(bookid, bookname, publicationDate, publisher, bookrackid, roomid)
        self.table1Widget.removeRow(row)
    def edit_row(self, row):
        bookid, bookname, publicationDate, publisher, bookrackid, roomid=self.table1Widget.item(row,0).text(),self.table1Widget.item(row,1).text(),self.table1Widget.item(row,2).text(),self.table1Widget.item(row,3).text(),self.table1Widget.item(row,4).text(),self.table1Widget.item(row,5).text()
        dialog = EditDialog(bookid, bookname, publicationDate, publisher, bookrackid, roomid)
        if dialog.exec():
            bookname, publicationDate, publisher, bookrackid, roomid = dialog.get_values()
            self.table1Widget.setItem(row, 1, QTableWidgetItem(bookname))
            self.table1Widget.setItem(row, 2, QTableWidgetItem(publicationDate))
            self.table1Widget.setItem(row, 3, QTableWidgetItem(publisher))
            self.table1Widget.setItem(row, 4, QTableWidgetItem(bookrackid))
            self.table1Widget.setItem(row, 5, QTableWidgetItem(roomid))

    def change_pwd_funct(self):
        self.change_=change_pwd_class(self.usrname)
        self.change_.show()

    def exit_(self):
        self.close()
        self.login=CustomDialog()
        self.login.show()

    def usrshow(self):
        key = self.search_usr.text()
        print(key)
        data = None
        self.show_usr.setRowCount(0)
        self.show_usr.setColumnCount(6)
        self.show_usr.setHorizontalHeaderLabels(["id","username", "password","is_root","modify","remove"])
        if key == "":
            data = Sql().search_user()
        else:
            data = Sql().search_user(key)
        for it in range(len(data)):
            self.show_usr.insertRow(it)
            (id, usrname,password,is_root) = data[it]
            self.show_usr.setItem(it, 0, QTableWidgetItem(str(id)))
            self.show_usr.setItem(it, 1, QTableWidgetItem(usrname))
            self.show_usr.setItem(it, 2, QTableWidgetItem(password))
            self.show_usr.setItem(it, 3, QTableWidgetItem(str(is_root)))


            button = QPushButton('修改')
            # button.clicked.connect(lambda checked, r=it: self.edit_(r))
            self.show_usr.setCellWidget(it, 4, button)


            button_delete = QPushButton('删除')
            # button_delete.clicked.connect(lambda checked, r=it: self.drop(r))
            self.show_usr.setCellWidget(it, 5, button_delete)
            self.show_usr.verticalHeader().setVisible(False)



class change_pwd_class(change_pwd.Ui_Form,QMainWindow):
    def __init__(self,usrname):
        super().__init__()
        self.setupUi(self)
        self.change_button.clicked.connect(self.change_pwd)
        self.lineEdit.setEchoMode(QLineEdit.EchoMode.Password)
        self.lineEdit_2.setEchoMode(QLineEdit.EchoMode.Password)
        self.usrname=usrname


    def change_pwd(self):
        pwd=self.lineEdit.text()
        pwd_sure=self.lineEdit_2.text()
        if pwd==pwd_sure:
            Sql().change_pwd(self.usrname,self.lineEdit.text())
            self.result.setText("更改中")
            self.result.startFadeOut()
            self.close()
        else:
            self.result.setText("密码不同，请检查后重新输入")

from PySide6.QtWidgets import QApplication
import sys

if __name__ == "__main__":
    app = QApplication([])
    dialog = MainShow("test")
    dialog.show()
    sys.exit(app.exec())
