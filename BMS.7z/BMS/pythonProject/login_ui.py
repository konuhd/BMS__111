# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login_ui.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QLabel,
    QLineEdit, QPushButton, QSizePolicy, QWidget)

from qfading import FadeOutLabel
import icon_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(696, 678)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setStyleSheet(u"*{\n"
"	background-color: rgb(255, 255, 255);\n"
"}\n"
"QFrame#frame{\n"
"	border-image:url(:/login/resources/img/preview.jpg);\n"
"}\n"
"#frame_2{\n"
"	background-color: rgba(161, 161, 161, 120);\n"
"}\n"
"#label{\n"
"	background-color: rgba(255, 255, 255, 100);\n"
"	font: 9pt \"\u534e\u6587\u96b6\u4e66\";\n"
"}\n"
"#label_5{\n"
"	border-radius:30px;\n"
"	background-color: rgba(145, 145, 145, 180);\n"
"}\n"
"#label_3{\n"
"	color: rgba(255, 255, 255, 200);\n"
"	background:transparent;\n"
"}\n"
"QLineEdit{\n"
"	background:transparent;\n"
"	border:none;\n"
"	border-bottom:1px solid rgba(255, 255, 255, 180);\n"
"}\n"
"#pushButton{\n"
"	border-radius:10px;\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(85, 170, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"	font: 9pt \"\u534e\u6587\u96b6\u4e66\";\n"
"	outline:none;\n"
"}\n"
"#pushButton:hover{\n"
"	background-color: rgb(115, 115, 115);\n"
"	outline:none;	\n"
"}\n"
"#label_4{\n"
"	background:transparent;\n"
"	color: rgb(25"
                        "5, 0, 0);\n"
"	font: 700 9pt \"Segoe Script\";\n"
"}\n"
"#pushButton_2{\n"
"background:transparent;\n"
"	color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(34, 56, 79, 255), stop:1 rgba(255, 255, 255, 255));\n"
"	outline:none;\n"
"}\n"
"#pushButton_3{\n"
"background:transparent;\n"
"	color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(34, 56, 79, 255), stop:1 rgba(255, 255, 255, 255));\n"
"	outline:none;\n"
"}")
        self.frame = QFrame(Dialog)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(90, 70, 491, 551))
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(0, 0, 491, 551))
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.label_3 = QLabel(self.frame_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(100, 110, 281, 51))
        font = QFont()
        font.setPointSize(15)
        self.label_3.setFont(font)
        self.label_5 = QLabel(self.frame_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(50, 60, 391, 421))
        self.label_5.setStyleSheet(u"")
        self.usrname = QLineEdit(self.frame_2)
        self.usrname.setObjectName(u"usrname")
        self.usrname.setGeometry(QRect(180, 210, 133, 31))
        self.usrname.setMinimumSize(QSize(133, 31))
        self.usrname.setMaximumSize(QSize(133, 16777215))
        self.password = QLineEdit(self.frame_2)
        self.password.setObjectName(u"password")
        self.password.setGeometry(QRect(180, 250, 133, 31))
        self.password.setMinimumSize(QSize(133, 31))
        self.password.setMaximumSize(QSize(133, 31))
        self.pushButton = QPushButton(self.frame_2)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(210, 290, 75, 24))
        self.pushButton.setStyleSheet(u"")
        self.pushButton.setLocale(QLocale(QLocale.English, QLocale.UnitedStates))
        self.label_4 = FadeOutLabel(self.frame_2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setEnabled(True)
        self.label_4.setGeometry(QRect(160, 320, 171, 41))
        self.label_4.setStyleSheet(u"#label_4{\n"
"qproperty-alignment:AlignCenter;\n"
"}")
        self.label = QLabel(self.frame_2)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 0, 491, 21))
        self.pushButton_2 = QPushButton(self.frame_2)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(470, 0, 21, 21))
        self.pushButton_2.setMaximumSize(QSize(21, 24))
        icon = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.ApplicationExit))
        self.pushButton_2.setIcon(icon)
        self.pushButton_3 = QPushButton(self.frame_2)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(450, 0, 21, 24))
        self.pushButton_3.setMaximumSize(QSize(31, 24))
        icon1 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.ListRemove))
        self.pushButton_3.setIcon(icon1)
        self.label_5.raise_()
        self.label_3.raise_()
        self.usrname.raise_()
        self.pushButton.raise_()
        self.label_4.raise_()
        self.label.raise_()
        self.pushButton_2.raise_()
        self.pushButton_3.raise_()
        self.password.raise_()

        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label_3.setText(QCoreApplication.translate("Dialog", u"               \u56fe\u4e66\u7ba1\u7406\u7cfb\u7edf", None))
        self.label_5.setText("")
        self.usrname.setPlaceholderText(QCoreApplication.translate("Dialog", u"username", None))
        self.password.setPlaceholderText(QCoreApplication.translate("Dialog", u"password", None))
        self.pushButton.setText(QCoreApplication.translate("Dialog", u"login in", None))
        self.label_4.setText("")
        self.label.setText(QCoreApplication.translate("Dialog", u"\u56fe\u4e66\u7ba1\u7406\u7cfb\u7edf", None))
        self.pushButton_2.setText("")
        self.pushButton_3.setText("")
    # retranslateUi

