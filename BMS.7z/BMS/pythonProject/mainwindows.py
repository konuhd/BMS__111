# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindows.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGroupBox, QHeaderView, QLabel,
    QLineEdit, QPushButton, QSizePolicy, QTabWidget,
    QTableWidget, QTableWidgetItem, QToolButton, QWidget)

from qfading import FadeOutLabel
import icon_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(839, 530)
        Form.setStyleSheet(u"#label{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#tabWidget{\n"
"board:none;\n"
"}\n"
"#add{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#add:hover{\n"
"	background-color: rgb(255, 255, 255);\n"
"}\n"
"#sub{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#sub:hover{\n"
"	background-color: rgb(255, 255, 255);\n"
"}")
        self.tabWidget = QTabWidget(Form)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(0, 0, 841, 531))
        self.tabWidget.setStyleSheet(u"#search_line{\n"
"	background:transparent;\n"
"	border:none;\n"
"	border-bottom:1px solid  rgb(0, 0, 0);\n"
"}\n"
"QTabBar::tab{\n"
"	height: 40px;\n"
"	width :150px;\n"
"	outline:none;\n"
"	background-color: rgb(0, 170, 255);\n"
"	font: 700 9pt \"Segoe Print\";\n"
"}\n"
"\n"
"QTabBar::tab:!selected{\n"
"	outline:none;\n"
"	background-color: rgb(175, 175, 175);\n"
"}\n"
"QTabBar::tab:selected:focus{\n"
"	border:none;\n"
"	outline:none;\n"
"}\n"
"QTabBar::tab:hover{\n"
"	outline:none;\n"
"	background-color: rgb(255, 255, 255);\n"
"}\n"
"#submit{\n"
"	border-radius:10px;\n"
"	background-color: rgb(223, 223, 223);\n"
"	outline:none;\n"
"}\n"
"#submit:hover{\n"
"	background-color: rgb(21, 21, 21);\n"
"}")
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.North)
        self.tabWidget.setTabShape(QTabWidget.TabShape.Triangular)
        self.tabWidget.setElideMode(Qt.TextElideMode.ElideRight)
        self.tabWidget.setTabsClosable(False)
        self.tabWidget.setTabBarAutoHide(False)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.search_line = QLineEdit(self.tab)
        self.search_line.setObjectName(u"search_line")
        self.search_line.setGeometry(QRect(250, 20, 251, 20))
        self.search_button = QPushButton(self.tab)
        self.search_button.setObjectName(u"search_button")
        self.search_button.setGeometry(QRect(510, 20, 24, 22))
        icon = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.EditFind))
        self.search_button.setIcon(icon)
        self.table1Widget = QTableWidget(self.tab)
        self.table1Widget.setObjectName(u"table1Widget")
        self.table1Widget.setGeometry(QRect(0, 40, 841, 441))
        self.label = QLabel(self.tab)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 0, 841, 41))
        self.tabWidget.addTab(self.tab, icon, "")
        self.label.raise_()
        self.search_line.raise_()
        self.search_button.raise_()
        self.table1Widget.raise_()
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.add = QToolButton(self.tab_2)
        self.add.setObjectName(u"add")
        self.add.setGeometry(QRect(0, 50, 41, 41))
        self.add.setStyleSheet(u"image url(:/icon/resources/icon/\u52a0\u53f7-icon.png)\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(203, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));")
        icon1 = QIcon()
        icon1.addFile(u":/icon/resources/icon/\u52a0\u53f7-icon.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.add.setIcon(icon1)
        self.sub = QToolButton(self.tab_2)
        self.sub.setObjectName(u"sub")
        self.sub.setGeometry(QRect(40, 50, 41, 41))
        self.sub.setStyleSheet(u"image url(:/icon/resources/icon/\u51cf\u53f7icon.png)")
        icon2 = QIcon()
        icon2.addFile(u":/icon/resources/icon/\u51cf\u53f7icon.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.sub.setIcon(icon2)
        self.tableWidget = QTableWidget(self.tab_2)
        if (self.tableWidget.columnCount() < 6):
            self.tableWidget.setColumnCount(6)
        __qtablewidgetitem = QTableWidgetItem()
        __qtablewidgetitem.setText(u"bookid");
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, __qtablewidgetitem5)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(0, 90, 841, 411))
        self.label_2 = QLabel(self.tab_2)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(0, -40, 841, 131))
        self.label_2.setStyleSheet(u"background-color: rgb(254, 235, 255);")
        self.submit = QPushButton(self.tab_2)
        self.submit.setObjectName(u"submit")
        self.submit.setGeometry(QRect(760, 50, 75, 41))
        self.submit.setStyleSheet(u"")
        self.submit_label = FadeOutLabel(self.tab_2)
        self.submit_label.setObjectName(u"submit_label")
        self.submit_label.setGeometry(QRect(260, 50, 161, 31))
        self.submit_label.setStyleSheet(u"#submit_label{\n"
"qproperty-alignment:AlignCenter;\n"
"	color: rgb(255, 0, 0);\n"
"}")
        icon3 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.ListAdd))
        self.tabWidget.addTab(self.tab_2, icon3, "")
        self.label_2.raise_()
        self.add.raise_()
        self.sub.raise_()
        self.tableWidget.raise_()
        self.submit.raise_()
        self.submit_label.raise_()
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tab_4.sizePolicy().hasHeightForWidth())
        self.tab_4.setSizePolicy(sizePolicy)
        self.tab_4.setMaximumSize(QSize(100000, 9999))
        self.groupBox = QGroupBox(self.tab_4)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(0, 0, 841, 481))
        self.change_password = QPushButton(self.groupBox)
        self.change_password.setObjectName(u"change_password")
        self.change_password.setGeometry(QRect(450, 430, 121, 31))
        self.show_usr = QTableWidget(self.groupBox)
        self.show_usr.setObjectName(u"show_usr")
        self.show_usr.setGeometry(QRect(50, 40, 771, 381))
        self.search_usr = QLineEdit(self.groupBox)
        self.search_usr.setObjectName(u"search_usr")
        self.search_usr.setGeometry(QRect(290, 10, 231, 20))
        self.pushbutton = QPushButton(self.groupBox)
        self.pushbutton.setObjectName(u"pushbutton")
        self.pushbutton.setGeometry(QRect(530, 10, 24, 22))
        self.pushbutton.setIcon(icon)
        self.adduser = QPushButton(self.groupBox)
        self.adduser.setObjectName(u"adduser")
        self.adduser.setGeometry(QRect(230, 430, 91, 31))
        icon4 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.UserAvailable))
        self.tabWidget.addTab(self.tab_4, icon4, "")

        self.retranslateUi(Form)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
#if QT_CONFIG(whatsthis)
        self.search_line.setWhatsThis(QCoreApplication.translate("Form", u"<html><head/><body><p><br/></p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.search_button.setText("")
        self.label.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("Form", u"\u67e5\u627e/\u4fee\u6539\u56fe\u4e66", None))
        self.add.setText(QCoreApplication.translate("Form", u"...", None))
        self.sub.setText(QCoreApplication.translate("Form", u"...", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Form", u"bookname", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Form", u"publicationDate", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Form", u"pulisher", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Form", u"bookrackid", None));
        ___qtablewidgetitem4 = self.tableWidget.horizontalHeaderItem(5)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("Form", u" roomid", None));
        self.label_2.setText("")
        self.submit.setText(QCoreApplication.translate("Form", u"submit", None))
        self.submit_label.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("Form", u"\u6dfb\u52a0\u56fe\u4e66", None))
        self.change_password.setText(QCoreApplication.translate("Form", u"change password", None))
        self.pushbutton.setText("")
        self.adduser.setText(QCoreApplication.translate("Form", u"add user", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), QCoreApplication.translate("Form", u"\u7528\u6237\u4fe1\u606f\u7ba1\u7406", None))
    # retranslateUi

